/* Advertising (public site only) */
(function () {
  var CONFIG = {
    enabled: true,                       // set to false to turn the banner script off
    src: 'https://bellnewyork.org/14/ac08932f873762e7317010cde9aacc98' // Adstra social banner script
  };

  if (CONFIG.enabled) {
    var s = document.createElement('script');
    s.src = CONFIG.src;
    s.async = true;
    s.setAttribute('data-cfasync', 'false');
    document.head.appendChild(s);
  }

  // Download button: open the direct link ad in a new tab (needs the click), the page itself goes to the ad/countdown page.
  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('.dl-btn') : null;
    if (!a) return;
    var ad = a.getAttribute('data-ad');
    if (ad) window.open(ad, '_blank', 'noopener');
  });

  // Ad page countdown. Time is taken from the server, which also refuses the file until the time has passed.
  var cd = document.getElementById('cd');
  if (cd) {
    var left = parseInt(cd.getAttribute('data-left'), 10) || 0,
        total = parseInt(cd.getAttribute('data-total'), 10) || left || 1,
        btn = document.getElementById('cdbtn'), n = document.getElementById('cdn'),
        msg = document.getElementById('cdmsg'), bar = document.getElementById('cdbar'),
        end = Date.now() + left * 1000, started = false;
    btn.addEventListener('click', function (e) { if (!started) e.preventDefault(); });
    (function tick() {
      var r = Math.max(0, Math.ceil((end - Date.now()) / 1000));
      n.textContent = r;
      bar.style.width = Math.min(100, (1 - (end - Date.now()) / (total * 1000)) * 100) + '%';
      if (r > 0) { setTimeout(tick, 250); return; }
      started = true; bar.style.width = '100%';
      btn.classList.remove('dis'); btn.removeAttribute('aria-disabled');
      msg.textContent = 'Your download is ready.';
      window.location.href = btn.getAttribute('href');
    })();
  }
})();
