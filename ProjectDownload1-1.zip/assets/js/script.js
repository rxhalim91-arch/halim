(function(){var b=document.querySelector('.mt'),n=document.getElementById('mn');if(b&&n)b.addEventListener('click',function(){var o=n.classList.toggle('open');b.setAttribute('aria-expanded',o)});
document.addEventListener('click',function(e){var d=document.querySelector('.dd[open]');if(d&&!d.contains(e.target))d.removeAttribute('open')})})();
