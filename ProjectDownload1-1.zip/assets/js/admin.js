(function(){var t=document.getElementById('sbt'),s=document.getElementById('sb'),m=document.createElement('div');m.className='scrim';document.body.appendChild(m);
function set(o){s.classList.toggle('open',o);m.classList.toggle('show',o);t.setAttribute('aria-expanded',o);t.setAttribute('aria-label',o?'Close menu':'Open menu')}
if(t&&s){t.addEventListener('click',function(){set(!s.classList.contains('open'))});m.addEventListener('click',function(){set(false)});s.addEventListener('click',function(e){if(e.target.closest('a'))set(false)});document.addEventListener('keydown',function(e){if(e.key==='Escape')set(false)})}
document.addEventListener('click',function(e){var c=e.target.closest('[data-confirm]');if(c&&!confirm(c.getAttribute('data-confirm')))e.preventDefault()});
var ti=document.getElementById('ti'),sl=document.getElementById('sl');if(ti&&sl&&!sl.value)ti.addEventListener('input',function(){if(!sl.dataset.m)sl.value=ti.value.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')});if(sl)sl.addEventListener('input',function(){sl.dataset.m=1});
document.querySelectorAll('form[enctype]').forEach(function(f){f.addEventListener('submit',function(e){
if(f.dataset.enc){f.enctype='application/x-www-form-urlencoded';return}
var b=f.querySelector('button.btn'),fi=f.querySelector('input[type=file][name=file]'),ti2=f.querySelector('input[type=file][name=thumb]'),cs=f.querySelector('input[name=csrf]').value;
var hasF=fi&&fi.files[0],hasT=ti2&&ti2.files[0];
function busy(v,t){if(b){b.disabled=v;b.textContent=v?(t||'Saving...'):'Save project'}}
if(!hasF&&!hasT){busy(true);f.enctype='application/x-www-form-urlencoded';return}
e.preventDefault();busy(true,'Preparing...');
function add(n,v){var h=document.createElement('input');h.type='hidden';h.name=n;h.value=v;f.appendChild(h)}
function b64(bl){return new Promise(function(ok,no){var r=new FileReader();r.onload=function(){ok(String(r.result).split(',')[1]||'')};r.onerror=function(){no(new Error('Could not read the file.'))};r.readAsDataURL(bl)})}
function shrink(fl){return new Promise(function(ok,no){var im=new Image(),u=URL.createObjectURL(fl);im.onload=function(){var w=Math.min(1000,im.naturalWidth),h=Math.round(im.naturalHeight*w/im.naturalWidth),c=document.createElement('canvas');c.width=w;c.height=h;var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(im,0,0,w,h);URL.revokeObjectURL(u);c.toBlob(function(bl){bl?ok(bl):no(new Error('Could not process the image.'))},'image/jpeg',.85)};im.onerror=function(){no(new Error('This image format is not supported. Use JPG, PNG or WebP.'))};im.src=u})}
function send(uid,off,data){var tries=0;return (function go(){return fetch('admin.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({act:'chunk',csrf:cs,uid:uid,off:off,data:data})}).then(function(r){return r.text().then(function(t){var j;try{j=JSON.parse(t)}catch(x){}if(j&&j.ok)return;if(j&&j.error)throw new Error(j.error);throw new Error('retry')})}).catch(function(err){if(err.message!=='retry'&&err.name!=='TypeError')throw err;if(++tries>=4)throw new Error('The connection was interrupted. Please check your network and try again.');return new Promise(function(r){setTimeout(r,800*tries)}).then(go)})})()}
async function chunked(fl){if(!fl.size)throw new Error('The file is empty.');var uid=Array.from(crypto.getRandomValues(new Uint8Array(12))).map(function(x){return ('0'+x.toString(16)).slice(-2)}).join(''),CH=524288,off=0;
while(off<fl.size){var part=fl.slice(off,off+CH);await send(uid,off,await b64(part));off+=part.size;busy(true,'Uploading '+Math.round(off/fl.size*100)+'%')}return uid}
(async function(){try{
if(hasF){var fl=fi.files[0],uid=await chunked(fl);add('file_up',uid);add('file_name',fl.name);fi.value=''}
if(hasT){var tf=ti2.files[0],bl=/^image\//.test(tf.type)?await shrink(tf):tf,nm=/^image\//.test(tf.type)?tf.name.replace(/\.[^.]+$/,'')+'.jpg':tf.name;add('thumb_b64',await b64(bl));add('thumb_name',nm);ti2.value=''}
f.dataset.enc=1;f.enctype='application/x-www-form-urlencoded';busy(true);f.submit()}catch(err){busy(false);alert(err.message||'Upload failed. Please try again.')}})()})})})();
